from pkg_resources import resource_filename

from qgis.PyQt.QtCore import QSettings, QUrl
from qgis.PyQt.QtGui import QDesktopServices


def openHelp():
    pass
