<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS><TS version="2.0" language="fr_FR" sourcelanguage="">
<context>
    <name>DimensionsSelectorPlugin</name>
    <message>
        <location filename="../dimensions_selector_plugin.py" line="95"/>
        <source>Settings</source>
        <translation>Réglages</translation>
    </message>
    <message>
        <location filename="../dimensions_selector_plugin.py" line="103"/>
        <source>Toggle filtering</source>
        <translation>Activation du filtrage</translation>
    </message>
    <message>
        <location filename="../dimensions_selector_plugin.py" line="120"/>
        <source>&amp;Dimensions selector</source>
        <translation>Sélecteur de &amp;dimensions</translation>
    </message>
    <message>
        <location filename="../dimensions_selector_plugin.py" line="92"/>
        <source>Dimensions selector</source>
        <translation>Sélecteur de dimensions</translation>
    </message>
</context>
<context>
    <name>DimensionsTableModel</name>
    <message>
        <location filename="../gui/settings_dialog.py" line="119"/>
        <source>Name</source>
        <translation>Nom</translation>
    </message>
    <message>
        <location filename="../gui/settings_dialog.py" line="123"/>
        <source>Choices</source>
        <translation>Valeurs</translation>
    </message>
    <message>
        <location filename="../gui/settings_dialog.py" line="139"/>
        <source>Active</source>
        <translation>Activé</translation>
    </message>
    <message>
        <location filename="../gui/settings_dialog.py" line="127"/>
        <source>Table</source>
        <translation>Table</translation>
    </message>
    <message>
        <location filename="../gui/settings_dialog.py" line="131"/>
        <source>Value field</source>
        <translation>Champ valeur</translation>
    </message>
    <message>
        <location filename="../gui/settings_dialog.py" line="135"/>
        <source>Label field</source>
        <translation>Champ texte</translation>
    </message>
</context>
<context>
    <name>LayerDimensionsTableModel</name>
    <message>
        <location filename="../gui/settings_dialog.py" line="182"/>
        <source>Layer</source>
        <translation>Couche</translation>
    </message>
    <message>
        <location filename="../gui/settings_dialog.py" line="187"/>
        <source>Name</source>
        <translation>Nom</translation>
    </message>
    <message>
        <location filename="../gui/settings_dialog.py" line="191"/>
        <source>Field</source>
        <translation>Champ</translation>
    </message>
    <message>
        <location filename="../gui/settings_dialog.py" line="195"/>
        <source>Active</source>
        <translation>Activé</translation>
    </message>
</context>
</TS>
